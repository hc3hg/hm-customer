library(tidyverse)
library(dplyr)
library(lubridate)
library(digest)
library(zoo)

# IMPORT H&M DATA
transaction_data <- read_csv("/Users/j9mis/Documents/J9 Documents/GT OMSA/2 Spring 2023/MGT 6203/Group Project/H&M Data/transactions_train.csv")
article_data <- read_csv("/Users/j9mis/Documents/J9 Documents/GT OMSA/2 Spring 2023/MGT 6203/Group Project/H&M Data/articles.csv")
customer_data <- read_csv("/Users/j9mis/Documents/J9 Documents/GT OMSA/2 Spring 2023/MGT 6203/Group Project/H&M Data/customers.csv")


# transaction_data <- transaction_data %>% 
#   left_join(article_data, by = "article_id")

data_subset <- transaction_data %>%  
  arrange(customer_id) %>% 
  slice_head(n = 500000) %>% 
  left_join(article_data, by = "article_id")

# function to calcualte mode
mode_fun <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

customer_transactions_pre <- data_subset %>% 
  filter(t_dat >= "2018-09-20" & t_dat <= "2019-02-28") %>% 
  group_by(customer_id) %>% 
  summarize(purch_total_pre = sum(price, na.rm = T),
            num_purch = n(),
            days_purch = n_distinct(t_dat),
            min_purch_dt = min(t_dat),
            max_purch_dt = max(t_dat),
            time_between_purch = max_purch_dt - min_purch_dt,
            time_since_last_purch = Sys.Date() - max_purch_dt,
            dept_max = mode_fun(index_code),
            online_pct = (sum(sales_channel_id == 2)/n())
            ) %>% 
  ungroup() %>% 
  left_join(customer_data, by = "customer_id") %>% 
 #mutate(newsletter = case_when)
  filter(!is.na(age)) %>% 
  # ADD VARS FOR JUST TWO OPTIONS
  mutate(fn_none = case_when(fashion_news_frequency == "NONE" | fashion_news_frequency == "None" ~ 1,
                             TRUE ~ 0),
         fn_monthly = case_when(fashion_news_frequency == "Monthly" ~ 1,
                                TRUE ~ 0),
         fn_regularly = case_when(fashion_news_frequency == "Regularly" ~ 1,
                                  TRUE ~ 0),
         club_none = case_when(club_member_status == "NONE" ~ 1,
                               TRUE ~ 0),
         club_pre = case_when(club_member_status == "PRE-CREATE" ~ 1,
                              TRUE ~ 0),
         club_active = case_when(club_member_status == "ACTIVE" ~ 1,
                                 TRUE ~ 0),
         club_left = case_when(club_member_status == "LEFT CLUB" ~ 1,
                               TRUE ~ 0))

customer_value_post <- data_subset %>% 
  filter(t_dat >= "2019-09-01" & t_dat <= "2020-02-29") %>% 
  group_by(customer_id) %>% 
  summarize(purch_total_post = sum(price, na.rm = T)) %>% 
  ungroup() 

customer_transactions <- customer_transactions_pre %>% 
  left_join(customer_value_post, by = "customer_id") %>% 
  mutate(purch_total_post = str_replace_na(purch_total_post, replacement = 0))

# REMOVE OUTLIERS


model_A <- lm(purch_total_post ~ purch_total_pre + num_purch + days_purch + time_between_purch + time_since_last_purch + age + dept_max, 
              data = customer_transactions)



rm(article_data)


transactions_pre <- transaction_data %>% 
  filter(t_dat >= "2018-09-20" & t_dat <= "2019-02-28")
  
transactions_post <- transaction_data %>% 
  filter(t_dat >= "2019-09-01" & t_dat <= "2020-02-29")



number of each in index code

