########################################################
## Program for creating the data frame for regression  #
## analysis. The H and M Customer data and transaction #
## loaded to data frame. Transaction data frame        #
## filtered to have the transactions for the period    #
## of the analysis. Lastly the transaction data is     #
## merged with customer data for analysis              #
########################################################
#Read Customer data
hmcust <- read.csv("customers.csv")
head(hmcust)
tail(hmcust)
summary(hmcust)
#Read Transaction data
hmtran <- read.csv("transactions_train.csv")
head(hmtran)
tail(hmtran)
summary(hmtran)
#Filter transactions for the date range from Sep 2018 till Feb 2019 for Analysis
subset_1 <- subset(hmtran, t_dat >= "2018-09-20" & t_dat <= "2019-02-28")
summary(subset_1)
head(subset_1)
tail(subset_1)
#Filter transactions for the date range from Sep 2019 till Feb 2020 for Analysis
subset_2 <- subset(hmtran, t_dat >= "2019-09-01" & t_dat <= "2020-02-29")
summary(subset_2)
head(subset_2)
tail(subset_2)
# Load the dplyr library for data manipulation
library(dplyr)
# Set the dplyr.print_max option to 100
options(dplyr.print_max = 100)
#Sum and count the transactions per customer from Sep 2018 till Feb 2019
summarized_data_1 <- subset_1 %>%
  group_by(customer_id) %>%
  summarize(initial_price = sum(price), initial_count = n())
print(head(summarized_data_1, n=10))
#Sum and count the transactions per customer from Sep 2019 till Feb 2020
summarized_data_2 <- subset_2 %>%
  group_by(customer_id) %>%
  summarize(final_price = sum(price), final_count = n())
print(head(summarized_data_2, n=10))
#Merge the 2 summarized data frames and include all the rows 
merged_df <- merge(summarized_data_1, summarized_data_2, by = "customer_id", all = TRUE)
print(head(merged_df, n=10))
#Replace all null values with 0
merged_df <- replace(merged_df, is.na(merged_df), 0)
print(head(merged_df, n=10))
summary(merged_df)
#Merge customer data frame with transaction merge data frame
master_df <- merge(hmcust, merged_df, by = "customer_id", all = FALSE)
print(head(master_df, n=10))
summary(master_df)
#remove rows where age is NA
master_df <- na.omit(master_df)
summary(master_df)
#Library ggplot
library(ggplot2)
#Scatter plot for age and final price
ggplot(master_df, aes(x=age, y=final_price)) + geom_point() +
  scale_colour_hue(l=50) + # Use a slightly darker palette than normal
  geom_smooth(method=lm,   # Add linear regression lines
              se=FALSE,    # Don't add shaded confidence region
              fullrange=TRUE) # Extend regression lines

#Unique combinations for FN, Active, club_member_status, fashion_news_frequency
unique_combinations <- unique(apply(master_df[, c("FN", "Active", "club_member_status", "fashion_news_frequency")], 1, 
                                    function(x) paste(x, collapse = "_")))
# print the unique combinations
print(unique_combinations)
#Club Member Status unique values
unique(master_df$club_member_status)
#fashion_news_frequency unique values
unique(master_df$fashion_news_frequency)
#As the value for FN and Active is 1 for all the records
#We will create indicator variables with the club_member_status
# and fashion_news_frequency
master_df<- master_df %>%
  mutate(CM_ACTIVE = ifelse(club_member_status=="ACTIVE",1,0)) %>%
  mutate(CM_CREATE = ifelse(club_member_status=="PRE-CREATE",1,0)) %>%
  mutate(CM_LEFT = ifelse(club_member_status=="LEFT CLUB",1,0)) %>%
  mutate(NL_REG = ifelse(fashion_news_frequency=="Regularly",1,0)) %>%
  mutate(NL_MONTHLY = ifelse(fashion_news_frequency=="Monthly",1,0))
head(master_df)
#Create Linear Regression Model
hm_lm <- lm(final_price ~ initial_price + age + CM_ACTIVE +
              CM_CREATE + CM_LEFT + NL_REG + NL_MONTHLY, data=master_df)
summary(hm_lm)
 
#create second linear regression model with significant predictors from hm_lm
#remove age as predictor as coefficient too close to zero
hm_lm2 <- lm(final_price ~ initial_price + CM_ACTIVE + NL_REG + NL_MONTHLY,
             data = master_df)
                                    
summary(hm_lm2)
                                    
                                    
#install.packages("encryptr")
#library(dplyr)
#library(encryptr)
#hm %>%  
#  decrypt(ï..customer_id, postal_code)
