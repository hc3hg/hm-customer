library(tidyverse)
library(dplyr)
library(lubridate)
library(digest)

# IMPORT H&M DATA
transaction_data <- read_csv("/Users/j9mis/Documents/J9 Documents/GT OMSA/2 Spring 2023/MGT 6203/Group Project/H&M Data/transactions_train.csv")
article_data <- read_csv("/Users/j9mis/Documents/J9 Documents/GT OMSA/2 Spring 2023/MGT 6203/Group Project/H&M Data/articles.csv")
customer_data <- read_csv("/Users/j9mis/Documents/J9 Documents/GT OMSA/2 Spring 2023/MGT 6203/Group Project/H&M Data/customers.csv")


# JOIN CUSTOMER AND ARTICLE INFO TO TRANSACTION DATA (multiple steps to help memory)
hm_data <- transaction_data %>% 
  left_join(customer_data, by = "customer_id")
rm(transaction_data) 
rm(customer_data)
hm_data <- hm_data %>% 
  left_join(article_data, by = "article_id")
rm(article_data)


# IMPORT IRS DATA
irs_data <- read_csv("/Users/j9mis/Downloads/20zpallagi.csv")
# grab just ZIP
zip_data <- irs_data[,2:3] %>% unique()


# SEE IF WE CAN JOIN TO IRS DATA BY HASING IRS DATA (H&M ZIPs are hashed)
zip_data <- zip_data %>% 
  rowwise() %>% 
  mutate(MD5 = digest(zipcode, algo = "md5", serialize = F),
         SHA1 = digest(zipcode, algo = "sha1", serialize = F),
         CRC32 = digest(zipcode, algo = "crc32", serialize = F),
         SHA256 = digest(zipcode, algo = "sha256", serialize = F),
         SHA512 = digest(zipcode, algo = "sha512", serialize = F),
         BLAKE3 = digest(zipcode, algo = "blake3", serialize = F),
         XXHASH32 = digest(zipcode, algo = "xxhash32", serialize = F),
         XXHASH64 = digest(zipcode, algo = "xxhash64", serialize = F),
         MURMUR32 = digest(zipcode, algo = "murmur32", serialize = F),
         SPOOKYHASH = digest(zipcode, algo = "spookyhash", serialize = T)) %>% 
  gather(key = "algo", value = "hashed_zip", -c(STATE,zipcode))

# spoiler - we can't :(
zip_joined <- customer_data %>% 
  left_join(zip_data2, by = c("postal_code" = "hashed_zip"))


# DATA EXPLORATION
summary(hm_data)

# get unique combinations of newsletter-related columns (with counts) to see if they are duplicative
newsletter_club_info <- hm_data %>% 
  group_by(FN, Active, club_member_status, fashion_news_frequency) %>% 
  summarize(count = n()) %>% 
  ungroup()

# newsletter_club_info1 <- hm_data %>% 
#   filter(t_dat >= ymd("2018/09/01") & t_dat < ymd("2019/03/1")) %>% 
#   group_by(FN, Active, club_member_status, fashion_news_frequency) %>% 
#   summarize(count = n()) %>% 
#   ungroup()

# clean up data using the info from above. there are some instances where the columns conflict and volume is low, so we will remove
hm_data2 <- hm_data %>% 
  # filter(!)) %>% 
  mutate(fn_status = case_when(fashion_news_frequency == "Monthly" & FN == 1 ~ "1",
                               is.na(fashion_news_frequency) & is.na(FN) ~ "0",
                               TRUE ~ "Unknown"
                               ),
         fn_frequency = case_when(fashion_news_frequency == "Monthly" & FN == 1 ~ "Monthly",
                                  fashion_news_frequency == "Regularly" & FN == 1 ~ "Regularly",
                                  is.na(fashion_news_frequency) & is.na(FN) ~ "Never",
                                  TRUE ~ "Unknown"),
         club_status = case_when(club_member_status == "LEFT CLUB" & is.na(Active) ~ NA_character_,
                                 is.na(Active) & is.na(club_member_status) ~ NA_character_,
                                 club_member_status == "ACTIVE" & Active == 1 ~ "Active",
                                 
                                 TRUE ~ "Unknown")) %>% 
  group_by(FN, fashion_news_frequency, fn_status, fn_frequency, Active, club_member_status, club_status) %>% 
  summarize(count = n()) %>% 
  ungroup()

# what percent of customers missing age?
customer_data %>% filter(is.na(age)) %>% nrow() / nrow(customer_data)
# filter out missing age because only ~1%
hm_data <- hm_data %>% filter(!is.na(age))
# plot of customer age
hist(customer_data$age)
# avg purchase volume by age
hm_data %>% 
  group_by(customer_id, age) %>% 
  summarize(transactions = n()) %>% 
  ungroup() %>% 
  group_by(age) %>% 
  summarize(avg_t = mean(transactions)) %>% 
  ungroup() %>% 
  plot()
# avg spend per item by age
hm_data %>% 
  group_by(customer_id, age) %>% 
  summarize(spend_masked = sum(price, na.rm = T)/n()) %>% 
  ungroup() %>% 
  group_by(age) %>% 
  summarize(avg_spend_masked = mean(spend_masked)) %>% 
  ungroup() %>% 
  plot()


# CUSTOMERS SUBSCRIBED OR NOT SUBSCRIBED TO FASHION NEWSLETTER
yes_fn <- customer_data %>% filter(!is.na(FN)) %>% select(customer_id)
no_fn <- customer_data %>% filter(is.na(FN)) %>% select(customer_id)

# TRANSACTIONS FOR NEWSLETTER/NO NEWSLETTER
fn_transact <- transaction_data %>% filter(customer_id %in% yes_fn)
no_fn_transact <- transaction_data %>% filter(customer_id %in% no_fn)

# NUMBER OF PURCHASES
nrow(fn_transact) / nrow(yes_fn)
nrow(no_fn_transact) / nrow(no_fn)

customer_data %>% pull(age) %>% median(na.rm = TRUE)



customer_freq <- transaction_data %>% 
  group_by(customer_id) %>% 
  summarize(count = n()) %>% 
  ungroup()


customer_freq$count[customer_freq$count >= 100 ] <- 100

ggplot(customer_freq, aes(x = count)) + geom_histogram(bins = 11) +
  labs(title="Transaction Volume Distribution", x="Transactions", y="Count") +
  scale_x_discrete(breaks = waiver(), 
                   labels = c("1-9", "10-19", "20-29", "30-39", "40-49",
                              "50-59", "60-69", "70-79", "80-89", "90-99", "100+")) + 
  scale_y_continuous()
# scale_x_binned(breaks = c(seq(0, 10, by=9)), 
#                    labels=c(seq(1,100, by=9), "100+"))




transaction_data %>% pull(customer_id) %>% unique() %>% length()
transaction_data %>% group_by(customer_id) %>% nrow()
transaction_data %>% pull(article_id) %>% unique() %>% length()












